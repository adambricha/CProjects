//Adam Bricha U9233-5585 and Alyssa Brown U27307759. This program uses a doubly linked list to do basic operations such as addition, subtraction, multiplication, and division. 
// The linked list allows the program to keep track of the previous operation that was performed allowing for the option to delete the previous operation

#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <sstream>

#include "CalcList.hpp"

using namespace std;


CalcList::CalcList():CalcListInterface() {

    curr = new Calculator; 
    curr -> LLOperator = ADDITION; 
    curr -> LLoperand = 0.0;     //initialzed value to 0
    curr -> final = 0.0; 
    curr -> next = curr; 
}

void CalcList::addnode(double& node_element) {

    ++count; 
    Calculator *prev = new Calculator;

    prev -> next = NULL;   
    prev -> final = 0.0; 
    prev -> LLoperand = 0.0; 
    prev -> LLOperator = ADDITION;

    if(curr == nullptr) {                //if the list is empty add the node to the begining of the linked list

        prev -> final = node_element;
        curr = prev;
        curr -> next = prev;

    }

    else {                             // if the list is not empty, add the node to the end of the linked list

        prev -> next = curr -> next;     
        prev -> final = curr -> next -> final; 
        curr -> next = prev;
    }

}

double CalcList::total() const {
    return curr->next->final;

}

void CalcList::newOperation(const FUNCTIONS func, const double operand) {

    double newnode = 0; 
    addnode(newnode);

switch(func){
    case ADDITION: 
        curr->next->LLOperator = ADDITION;    //set the operator to additon
        curr->next->LLoperand = operand;
        curr->next->final += operand;
        break;

    case SUBTRACTION: 
        curr->next->LLOperator = SUBTRACTION;  //set the operator to subtraction
        curr->next->LLoperand = operand;
        curr->next->final -= operand;
    break;

    case MULTIPLICATION:
        curr->next->LLOperator = MULTIPLICATION;  //set the operator to division
        curr->next->LLoperand = operand;
        curr->next->final *= operand;
    break;

    case DIVISION: 
        if(operand >= 0 && operand < 1.00) {      //if the user tries to divide something by zero
            removeLastOperation();                //delete the try and prompt the user
            throw "Division by zero"; 
        }
        curr->next->LLOperator = DIVISION;
        curr->next->LLoperand = operand;
        curr->next->final /= operand;
    break;

    default:
        cout << "Not an Operation. Try again." << endl;   //default case
    }
}

void CalcList::removeLastOperation() {

    if(EmptyList()) {
                                   //check if the list is empty, nothing to remove
        throw "List is empty";
        
    }

    else {
        --count;
        Calculator* recentNode = curr -> next;

    if(recentNode == curr) {
        curr = NULL;
    }

    else {
        curr -> next = recentNode -> next;
    }

    delete recentNode;  //free memory for most recent node

    }

}

std::string CalcList::toString(unsigned short precision) const { // defining the toString

    std::stringstream outputstring; // create a stringstream to print to the user
    std::string output = "";   //empty string 

    int reverse = count;

    Calculator* p = new Calculator;   //Allocate memory for point p

    p = curr->next;
    outputstring.precision(precision);

    while(p->final != 0) {

        outputstring << reverse << ": ";
        outputstring << fixed << p->next->final;
    
        if(p->LLOperator == ADDITION) {
            outputstring << "+";               //if additon output 
        }

        else if(p->LLOperator == SUBTRACTION) {
            outputstring << "-";               //if subtraction output
        }

        else if(p->LLOperator == MULTIPLICATION) {
            outputstring << "*";                 //if multiplcation output
        }

        else if(p->LLOperator == DIVISION) {
            outputstring << "/";               //if division output
        }

        outputstring << p->LLoperand; 
        outputstring << "=";                  
        outputstring << p->final;

        outputstring << endl;
 
        p = p->next;   //move p

        --reverse; 

    }

    return outputstring.str();   //prints the final output on the screen
    

}




