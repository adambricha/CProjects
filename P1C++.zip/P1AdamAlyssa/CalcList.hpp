
#include "CalcListInterface.hpp"

class Calculator {           
    friend class CalcList;         //inherited from class CalcList
    FUNCTIONS LLOperator;       
    Calculator *next;  
    double final,LLoperand;
};

class CalcList: public CalcListInterface { 

    private:               //no other classes will be able to access this data 
    Calculator* curr; 

    protected:            //Other classes that inherit can modify this data
    int count = 0;        //count to keep track of current operations
    void addnode(double& node_element);   //function prototype for elements
    

    public:
    CalcList();
    bool EmptyList() {         
        return (count == 0);
    }

    double total() const;
    void newOperation(const FUNCTIONS func, const double operand);
    void removeLastOperation();
    std::string toString(unsigned short precision) const;

    
};